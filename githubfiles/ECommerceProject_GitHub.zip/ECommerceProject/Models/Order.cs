namespace Models;

public class Order
{
    private int _id;
    private int _userId;
    private string _storeId;
    private List<OrderItem> _items;
    private double _total;
    private OrderStatus _status;
    private DateTime _createdAt;
    private string _shippingAddress;

    public Order(int id, int userId, string storeId, string shippingAddress)
    {
        _id = id;
        _userId = userId;
        _storeId = storeId;
        _items = new List<OrderItem>();
        _total = 0;
        _status = OrderStatus.Pending;
        _createdAt = DateTime.Now;
        _shippingAddress = shippingAddress;
    }

    public int GetId() => _id;
    public int GetUserId() => _userId;
    public string GetStoreId() => _storeId;
    public List<OrderItem> GetItems() => _items;
    public double GetTotal() => _total;
    public OrderStatus GetStatus() => _status;
    public DateTime GetCreatedAt() => _createdAt;
    public string GetShippingAddress() => _shippingAddress;

    public void AddItem(OrderItem item) { _items.Add(item); _total += item.GetSubtotal(); }
    public void SetStatus(OrderStatus status) => _status = status;

    public string ToCsv() => $"{_id},{_userId},{_storeId},{_total},{_status},{_createdAt:yyyy-MM-dd},{_shippingAddress}";
}

public class OrderItem
{
    private int _productId;
    private string _productName;
    private int _quantity;
    private double _unitPrice;

    public OrderItem(int productId, string productName, int quantity, double unitPrice)
    {
        _productId = productId;
        _productName = productName;
        _quantity = quantity;
        _unitPrice = unitPrice;
    }

    public int GetProductId() => _productId;
    public string GetProductName() => _productName;
    public int GetQuantity() => _quantity;
    public double GetUnitPrice() => _unitPrice;
    public double GetSubtotal() => _quantity * _unitPrice;
}

public enum OrderStatus { Pending, Confirmed, Shipped, Delivered, Cancelled }
