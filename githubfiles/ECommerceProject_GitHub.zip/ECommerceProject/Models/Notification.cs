namespace Models;

public class Notification
{
    private int _id;
    private int _userId;
    private string _message;
    private NotificationType _type;
    private bool _isRead;
    private DateTime _createdAt;

    public Notification(int id, int userId, string message, NotificationType type)
    {
        _id = id;
        _userId = userId;
        _message = message;
        _type = type;
        _isRead = false;
        _createdAt = DateTime.Now;
    }

    public int GetId() => _id;
    public int GetUserId() => _userId;
    public string GetMessage() => _message;
    public NotificationType GetType() => _type;
    public bool IsRead() => _isRead;
    public DateTime GetCreatedAt() => _createdAt;

    public void MarkAsRead() => _isRead = true;

    public string ToCsv() => $"{_id},{_userId},{_message},{_type},{_isRead},{_createdAt:yyyy-MM-dd HH:mm}";
}

public enum NotificationType { Order, Offer, NewProduct, Message, System }
