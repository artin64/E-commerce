namespace Models;

public class Product
{
    private int _id;
    private string _name;
    private string _description;
    private double _price;
    private int _stock;
    private int _categoryId;
    private string _storeId;
    private List<string> _tags;
    private List<string> _photoUrls;
    private double _rating;
    private int _reviewCount;

    public Product(int id, string name, string description, double price, int stock, int categoryId, string storeId)
    {
        _id = id;
        _name = name;
        _description = description;
        _price = price;
        _stock = stock;
        _categoryId = categoryId;
        _storeId = storeId;
        _tags = new List<string>();
        _photoUrls = new List<string>();
        _rating = 0.0;
        _reviewCount = 0;
    }

    public int GetId() => _id;
    public string GetName() => _name;
    public string GetDescription() => _description;
    public double GetPrice() => _price;
    public int GetStock() => _stock;
    public int GetCategoryId() => _categoryId;
    public string GetStoreId() => _storeId;
    public List<string> GetTags() => _tags;
    public List<string> GetPhotoUrls() => _photoUrls;
    public double GetRating() => _rating;
    public int GetReviewCount() => _reviewCount;

    public void SetName(string name) => _name = name;
    public void SetDescription(string description) => _description = description;
    public void SetPrice(double price) => _price = price;
    public void SetStock(int stock) => _stock = stock;
    public void SetCategoryId(int categoryId) => _categoryId = categoryId;
    public void AddTag(string tag) => _tags.Add(tag);
    public void AddPhoto(string url) => _photoUrls.Add(url);
    public void UpdateRating(double rating, int count) { _rating = rating; _reviewCount = count; }

    public string ToCsv()
        => $"{_id},{_name},{_description},{_price},{_stock},{_categoryId},{_storeId},{_rating},{_reviewCount}";
}
