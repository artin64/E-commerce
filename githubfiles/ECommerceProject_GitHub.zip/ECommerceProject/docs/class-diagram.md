# Diagrami i Klasave — E-Commerce Multi-Vendor Platform

## Klasat dhe Atributet

```
┌─────────────────────────────────────┐
│              Product                │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _name: string                     │
│ - _description: string              │
│ - _price: double                    │
│ - _stock: int                       │
│ - _categoryId: int                  │
│ - _storeId: string                  │
│ - _tags: List<string>               │
│ - _photoUrls: List<string>          │
│ - _rating: double                   │
│ - _reviewCount: int                 │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetName(): string                 │
│ + GetPrice(): double                │
│ + GetStock(): int                   │
│ + GetStoreId(): string              │
│ + GetRating(): double               │
│ + SetName(string): void             │
│ + SetPrice(double): void            │
│ + SetStock(int): void               │
│ + AddTag(string): void              │
│ + AddPhoto(string): void            │
│ + UpdateRating(double, int): void   │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│             Category                │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _name: string                     │
│ - _storeId: string                  │
│ - _sortOrder: int                   │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetName(): string                 │
│ + GetStoreId(): string              │
│ + GetSortOrder(): int               │
│ + SetName(string): void             │
│ + SetSortOrder(int): void           │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│               User                  │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _email: string                    │
│ - _passwordHash: string             │
│ - _name: string                     │
│ - _address: string                  │
│ - _role: UserRole                   │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetEmail(): string                │
│ + GetName(): string                 │
│ + GetRole(): UserRole               │
│ + SetName(string): void             │
│ + SetAddress(string): void          │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│               Store                 │
├─────────────────────────────────────┤
│ - _id: string                       │
│ - _name: string                     │
│ - _ownerId: int                     │
│ - _qrCode: string                   │
│ - _theme: string                    │
│ - _primaryColor: string             │
│ - _backgroundColor: string          │
│ - _isActive: bool                   │
├─────────────────────────────────────┤
│ + GetId(): string                   │
│ + GetName(): string                 │
│ + GetOwnerId(): int                 │
│ + GetQrCode(): string               │
│ + GetTheme(): string                │
│ + IsActive(): bool                  │
│ + SetTheme(string): void            │
│ + SetPrimaryColor(string): void     │
│ + SetActive(bool): void             │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│               Order                 │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _userId: int                      │
│ - _storeId: string                  │
│ - _items: List<OrderItem>           │
│ - _total: double                    │
│ - _status: OrderStatus              │
│ - _createdAt: DateTime              │
│ - _shippingAddress: string          │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetUserId(): int                  │
│ + GetStoreId(): string              │
│ + GetTotal(): double                │
│ + GetStatus(): OrderStatus          │
│ + AddItem(OrderItem): void          │
│ + SetStatus(OrderStatus): void      │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│             OrderItem               │
├─────────────────────────────────────┤
│ - _productId: int                   │
│ - _productName: string              │
│ - _quantity: int                    │
│ - _unitPrice: double                │
├─────────────────────────────────────┤
│ + GetProductId(): int               │
│ + GetQuantity(): int                │
│ + GetUnitPrice(): double            │
│ + GetSubtotal(): double             │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│               Review                │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _productId: int                   │
│ - _userId: int                      │
│ - _rating: int                      │
│ - _comment: string                  │
│ - _createdAt: DateTime              │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetProductId(): int               │
│ + GetRating(): int                  │
│ + GetComment(): string              │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│               Cart                  │
├─────────────────────────────────────┤
│ - _userId: int                      │
│ - _storeId: string                  │
│ - _items: List<CartItem>            │
├─────────────────────────────────────┤
│ + GetUserId(): int                  │
│ + GetItems(): List<CartItem>        │
│ + AddProduct(Product, int): void    │
│ + RemoveProduct(int): void          │
│ + UpdateQuantity(int, int): void    │
│ + GetTotal(): double                │
│ + Clear(): void                     │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│             GiftCard                │
├─────────────────────────────────────┤
│ - _code: string                     │
│ - _value: double                    │
│ - _storeId: string                  │
│ - _isUsed: bool                     │
│ - _expiresAt: DateTime              │
├─────────────────────────────────────┤
│ + GetCode(): string                 │
│ + GetValue(): double                │
│ + IsValid(): bool                   │
│ + MarkAsUsed(): void                │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│          Advertisement              │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _storeId: string                  │
│ - _title: string                    │
│ - _imageUrl: string                 │
│ - _linkUrl: string                  │
│ - _position: AdPosition             │
│ - _isActive: bool                   │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetTitle(): string                │
│ + GetPosition(): AdPosition         │
│ + IsActive(): bool                  │
│ + SetActive(bool): void             │
│ + SetPosition(AdPosition): void     │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│           Notification              │
├─────────────────────────────────────┤
│ - _id: int                          │
│ - _userId: int                      │
│ - _message: string                  │
│ - _type: NotificationType           │
│ - _isRead: bool                     │
│ - _createdAt: DateTime              │
├─────────────────────────────────────┤
│ + GetId(): int                      │
│ + GetUserId(): int                  │
│ + GetMessage(): string              │
│ + IsRead(): bool                    │
│ + MarkAsRead(): void                │
│ + ToCsv(): string                   │
└─────────────────────────────────────┘
```

---

## Interfaces (Services Layer)

```
«interface»                          «interface»
IRepository<T>                       IProductService
─────────────────                    ─────────────────────────────
+ GetAll(): List<T>                  + GetAll(storeId): List<Product>
+ GetById(int): T?                   + GetById(int): Product?
+ Add(T): void                       + AddProduct(Product): void
+ Update(T): void                    + UpdateProduct(Product): void
+ Delete(int): void                  + DeleteProduct(int): void
+ Save(): void                       + Search(query, storeId): List<Product>
                                     + Filter(...): List<Product>

«interface»                          «interface»
IOrderService                        IAuthService
─────────────────────────────        ─────────────────────────────
+ CreateOrder(...): Order            + Login(email, pwd): User?
+ GetById(int): Order?               + Register(...): User
+ GetUserOrders(int): List<Order>    + ChangePassword(...): bool
+ GetStoreOrders(str): List<Order>
+ UpdateStatus(int, status): void

«interface»                          «interface»
IStoreService                        ICartService
─────────────────────────────        ─────────────────────────────
+ CreateStore(name, int): Store      + GetCart(int, str): Cart
+ GetById(str): Store?               + AddProduct(...): void
+ UpdateTheme(...): void             + RemoveProduct(...): void
+ SetActive(str, bool): void         + UpdateQuantity(...): void
+ GetAll(): List<Store>              + GetTotal(...): double
                                     + Clear(...): void

«interface»                          «interface»
IReviewService                       INotificationService
─────────────────────────────        ─────────────────────────────
+ GetByProduct(int): List<Review>    + Send(int, str, type): void
+ AddReview(Review): void            + GetUnread(int): List<Notif>
+ GetAverageRating(int): double      + MarkAsRead(int): void

«interface»
IAnalyticsService
─────────────────────────────
+ GetTotalRevenue(str): double
+ GetTopProducts(str, int): List<Product>
+ GetVisitorCount(str): int
+ GetOrderCount(str): int
```

---

## Relacionet

```
Store        1 ──────────── * Product         (Një dyqan ka shumë produkte)
Store        1 ──────────── * Category        (Një dyqan ka shumë kategori)
Store        1 ──────────── * Advertisement   (Një dyqan ka shumë reklama)
Store        1 ──────────── 1 User (owner)    (Çdo dyqan ka një pronar)

Category     1 ──────────── * Product         (Një kategori ka shumë produkte)

User         1 ──────────── * Order           (Një user bën shumë porosi)
User         1 ──────────── 1 Cart            (Çdo user ka një shportë)
User         1 ──────────── * Review          (Një user shkruan shumë review)
User         1 ──────────── * Notification    (Një user merr shumë njoftime)

Order        * ──────────── * Product         (Porosi — Produkte, nëpërmjet OrderItem)
Order        1 ──────────── * OrderItem       (Një porosi ka shumë artikuj)
OrderItem    * ──────────── 1 Product         (Çdo artikull i referohet një produkti)

Product      1 ──────────── * Review          (Një produkt ka shumë vlerësime)

GiftCard     * ──────────── 1 Store           (Gift cards lidhen me dyqanin)

IRepository<T>  ◁────────── FileRepository<T>   (Implementim)
IProductService ◁────────── ProductService       (Implementim)
IOrderService   ◁────────── OrderService         (Implementim)
IAuthService    ◁────────── AuthService          (Implementim)
IStoreService   ◁────────── StoreService         (Implementim)
ICartService    ◁────────── CartService          (Implementim)
IReviewService  ◁────────── ReviewService        (Implementim)
INotificationService ◁───── NotificationService  (Implementim)
IAnalyticsService ◁──────── AnalyticsService     (Implementim)

ProductService  ──uses──►  IRepository<Product>  (DIP)
OrderService    ──uses──►  IRepository<Order>    (DIP)
OrderService    ──uses──►  INotificationService  (DIP)
ReviewService   ──uses──►  IRepository<Review>   (DIP)
ReviewService   ──uses──►  IProductService       (DIP)
AnalyticsService ──uses──► IOrderService         (DIP)
AnalyticsService ──uses──► IProductService       (DIP)
```

---

## Enumeracionet

```
UserRole          OrderStatus       AdPosition            NotificationType
──────────        ───────────       ──────────────────    ────────────────
Buyer             Pending           TopBanner             Order
Seller            Confirmed         SideBar               Offer
SuperAdmin        Shipped           HomeHero              NewProduct
                  Delivered         BetweenProducts       Message
                  Cancelled         Footer                System
```
