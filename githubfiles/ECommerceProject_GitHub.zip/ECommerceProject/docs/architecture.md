# Dokumentimi i Arkitekturës — E-Commerce Multi-Vendor Platform

## Përshkrim i Sistemit

Platforma është një sistem E-Commerce Multi-Vendor shumë i avancuar që lejon shumë shitës të ndryshëm të krijojnë dhe menaxhojnë dyqanet e tyre të personalizuara brenda të njëjtit sistem. Çdo dyqan është plotësisht i izoluar nga dyqanet e tjera.

---

## Arkitektura e Zgjedhur: Layered Architecture (Shtresa të Ndara)

Projekti ndjek **Layered Architecture** me 4 shtresa kryesore:

```
┌──────────────────────────────────────────────┐
│                   UI Layer                   │  ← Ndërveprim me përdoruesin
├──────────────────────────────────────────────┤
│              Services Layer                  │  ← Logjika e biznesit
│         (+ Interfaces/ subfolder)            │
├──────────────────────────────────────────────┤
│               Data Layer                     │  ← Repository Pattern
│        (IRepository + FileRepository)        │
├──────────────────────────────────────────────┤
│              Models Layer                    │  ← Strukturat e të dhënave
└──────────────────────────────────────────────┘
```

---

## Shtresat dhe Përgjegjësitë

### 1. Models Layer (`Models/`)

**Përgjegjësia:** Vetëm strukturat e të dhënave — pa asnjë logjikë biznesi.

| Klasa | Përshkrimi |
|-------|-----------|
| `Product` | Produkt me çmim, stok, kategori, vlerësim |
| `Category` | Kategori produktesh per dyqan |
| `User` | Përdorues me rol (Buyer, Seller, SuperAdmin) |
| `Store` | Dyqan me ID unike, temë, QR Code |
| `Order` | Porosi me artikuj dhe status |
| `OrderItem` | Artikull brenda porosisë |
| `Review` | Vlerësim me yje dhe koment |
| `Cart` | Shportë me artikuj dhe total |
| `CartItem` | Artikull brenda shportës |
| `GiftCard` | Kartë dhurate me kod unik |
| `Advertisement` | Reklamë me pozicion në faqe |
| `Notification` | Njoftim për përdoruesin |

**Arsyeja:** Ndarja e të dhënave nga logjika siguron ndryshime pa efekte anësore.

---

### 2. Data Layer (`Data/`)

**Përgjegjësia:** Menaxhimi i aksesit dhe ruajtjes së të dhënave. Implementon Repository Pattern.

#### `IRepository<T>` — Interface

```csharp
public interface IRepository<T>
{
    List<T> GetAll();
    T? GetById(int id);
    void Add(T entity);
    void Update(T entity);
    void Delete(int id);
    void Save();
}
```

#### `FileRepository<T>` — Implementimi CSV

- Lexon dhe shkruan të dhëna nga file CSV
- Generic — funksionon për çdo tip entity
- Pranon funksione serialize/deserialize si parametra

**Arsyeja:** Repository Pattern ndan logjikën e aksesit të të dhënave nga logjika e biznesit. Nëse ndryshojmë burim të dhënash (CSV → Database), ndryshojmë vetëm Data Layer pa prekur Services.

---

### 3. Services Layer (`Services/`)

**Përgjegjësia:** Tërë logjika e biznesit e platformës.

#### Interfaces (`Services/Interfaces/`)

| Interface | Shërbimi |
|-----------|---------|
| `IProductService` | Menaxhimi i produkteve, kërkim, filtrim |
| `IOrderService` | Krijimi dhe menaxhimi i porosive |
| `IAuthService` | Login, regjistrim, ndryshim fjalëkalimi |
| `IStoreService` | Krijimi dhe konfigurimi i dyqaneve |
| `ICartService` | Menaxhimi i shportës |
| `IReviewService` | Vlerësimet dhe notat mesatare |
| `INotificationService` | Dërgimi dhe leximi i njoftimeve |
| `IAnalyticsService` | Statistika dhe analitikë |

#### Implementimet

| Implementimi | Interface | Varësia |
|-------------|-----------|---------|
| `ProductService` | `IProductService` | `IRepository<Product>` |
| `OrderService` | `IOrderService` | `IRepository<Order>`, `INotificationService` |
| `AuthService` | `IAuthService` | `IRepository<User>` |
| `StoreService` | `IStoreService` | `IRepository<Store>` |
| `CartService` | `ICartService` | In-memory Dictionary |
| `ReviewService` | `IReviewService` | `IRepository<Review>`, `IProductService` |
| `NotificationService` | `INotificationService` | `IRepository<Notification>` |
| `AnalyticsService` | `IAnalyticsService` | `IOrderService`, `IProductService` |

**Arsyeja:** Çdo shërbim ka interface të vetin (ISP). Shërbimet varen nga abstraktime, jo implementime (DIP). Kjo lejon testim dhe ndryshim të lehtë.

---

### 4. UI Layer (`UI/`)

**Përgjegjësia:** Vetëm ndërveprim me përdoruesin. Inicializon shërbimet dhe menaxhon fluksin e aplikacionit.

- `App.cs` — kryon Dependency Injection dhe menaxhon navigimin
- Nuk përmban logjikë biznesi
- Nuk akseson direkt repository-t

---

### 5. Program.cs (Entry Point)

```csharp
// Maksimumi 5 rreshta — vetëm inicializim
using UI;
class Program
{
    static void Main(string[] args)
    {
        var app = new App();
        app.Run();
    }
}
```

---

## Funksionalitetet Kryesore të Platformës

| Funksionaliteti | Ku Implementohet |
|----------------|-----------------|
| Multi-Vendor System | `Store` model + `StoreService` |
| ID Unike + QR Code | `Store.GenerateQrCodeUrl()` |
| Izolim i Dyqaneve | `storeId` filtrues në çdo shërbim |
| Shopping Cart | `Cart` model + `CartService` |
| Sistem Porosish | `Order` model + `OrderService` |
| Autentikim i Sigurt | `AuthService` me SHA-256 hash |
| Reviews & Ratings | `Review` model + `ReviewService` |
| Gift Cards | `GiftCard` model |
| Njoftime | `Notification` model + `NotificationService` |
| Reklama | `Advertisement` model |
| Analytics | `AnalyticsService` |
| Tematizim i Dyqanit | `Store.theme`, `primaryColor`, `backgroundColor` |
| Advanced Filters | `ProductService.Filter()` |
| Search System | `ProductService.Search()` |

---

## Parimet SOLID — Zbatimi i Plotë

### S — Single Responsibility Principle (SRP)
Çdo klasë dhe shtresë ka vetëm një arsye ndryshimi:
- `Models` → vetëm struktura e të dhënave
- `Services` → vetëm logjika e biznesit
- `Data` → vetëm akses dhe ruajtje e të dhënave
- `UI` → vetëm ndërveprim me përdoruesin
- `Program.cs` → vetëm inicializim

### O — Open/Closed Principle (OCP)
`IRepository<T>` lejon shtimin e implementimeve të reja pa modifikuar kodin ekzistues:
```
FileRepository<T>      → implementimi aktual (CSV)
DatabaseRepository<T>  → mund të shtohet pa ndryshuar asgjë tjetër
ApiRepository<T>       → mund të shtohet pa ndryshuar asgjë tjetër
```

### L — Liskov Substitution Principle (LSP)
`FileRepository<T>` mund të zëvendësohet me çdo implementim tjetër të `IRepository<T>` pa ndryshuar sjelljen e sistemit. `ProductService` funksionon njëlloj pavarësisht implementimit.

### I — Interface Segregation Principle (ISP)
Çdo shërbim ka interface të vetin specifike. Asnjë klasë nuk detyrohet të implementojë metoda që nuk i nevojiten:
- `IProductService` — vetëm operacione produktesh
- `IOrderService` — vetëm operacione porosish
- `IAuthService` — vetëm autentikim
- etj.

### D — Dependency Inversion Principle (DIP)
Shërbimet e nivelit të lartë varen nga abstraktime (interfaces), jo nga implementime konkrete:
```csharp
// ProductService varet nga IRepository<Product>
// JO nga FileRepository<Product>
public ProductService(IRepository<Product> repository) { ... }
```
Dependency Injection realizohet në `App.cs`.

---

## Vendime Arkitekturore dhe Arsyet

| Vendimi | Arsyeja |
|---------|---------|
| Layered Architecture | Ndarje e qartë e përgjegjësive, mirëmbajtje e lehtë |
| Repository Pattern | Abstraksion i aksesit në të dhëna, ndërrueshmëri burimi |
| Generic Repository `IRepository<T>` | Ripërdorim i kodit, reduktim i duplikimit |
| Interface për çdo shërbim | ISP, testueshmëri, zëvendësueshmëri |
| Dependency Injection në `App.cs` | DIP, konfigurabilitet, testim i lehtë |
| SHA-256 për fjalëkalime | Siguri e të dhënave të përdoruesit |
| `storeId` si filtër universal | Izolim i plotë i dyqaneve (Multi-Vendor) |
| File CSV për ruajtje | E thjeshtë dhe e përshtatshme për projekt akademik |
| `Guid` për Store ID | Garanton unicitet automatik |

---

## Struktura e Plotë e Projektit

```
ECommerceProject/
│
├── Models/
│   ├── Product.cs
│   ├── Category.cs
│   ├── User.cs
│   ├── Store.cs
│   ├── Order.cs
│   ├── Review.cs
│   ├── Cart.cs
│   ├── GiftCard.cs
│   ├── Advertisement.cs
│   └── Notification.cs
│
├── Services/
│   ├── Interfaces/
│   │   └── IServices.cs
│   ├── ProductService.cs
│   ├── OrderService.cs
│   └── Services.cs
│
├── Data/
│   ├── IRepository.cs
│   └── FileRepository.cs
│
├── UI/
│   └── App.cs
│
├── docs/
│   ├── architecture.md     ← ky file
│   └── class-diagram.md
│
├── Program.cs
├── README.md
└── .gitignore
```
