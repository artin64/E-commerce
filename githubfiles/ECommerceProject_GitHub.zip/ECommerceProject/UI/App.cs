using Models;
using Services;
using Services.Interfaces;
using Data;

namespace UI;

public class App
{
    private IAuthService _authService;
    private IProductService _productService;
    private IOrderService _orderService;
    private IStoreService _storeService;
    private ICartService _cartService;
    private INotificationService _notificationService;
    private IAnalyticsService _analyticsService;
    private IReviewService _reviewService;

    private User? _currentUser;
    private Store? _currentStore;

    public App()
    {
        // Dependency Injection — DIP i aplikuar plotësisht
        var notifRepo = new FileRepository<Notification>(
            "data/notifications.csv",
            line => { var p = line.Split(','); return new Notification(int.Parse(p[0]), int.Parse(p[1]), p[2], Enum.Parse<NotificationType>(p[3])); },
            n => n.ToCsv(),
            n => n.GetId());

        _notificationService = new NotificationService(notifRepo);

        var userRepo = new FileRepository<User>(
            "data/users.csv",
            line => { var p = line.Split(','); return new User(int.Parse(p[0]), p[1], p[2], p[3], p[4], Enum.Parse<UserRole>(p[5])); },
            u => u.ToCsv(),
            u => u.GetId());

        var productRepo = new FileRepository<Product>(
            "data/products.csv",
            line => { var p = line.Split(','); return new Product(int.Parse(p[0]), p[1], p[2], double.Parse(p[3]), int.Parse(p[4]), int.Parse(p[5]), p[6]); },
            p => p.ToCsv(),
            p => p.GetId());

        var orderRepo = new FileRepository<Order>(
            "data/orders.csv",
            line => { var p = line.Split(','); return new Order(int.Parse(p[0]), int.Parse(p[1]), p[2], p[6]); },
            o => o.ToCsv(),
            o => o.GetId());

        var reviewRepo = new FileRepository<Review>(
            "data/reviews.csv",
            line => { var p = line.Split(','); return new Review(int.Parse(p[0]), int.Parse(p[1]), int.Parse(p[2]), int.Parse(p[3]), p[4]); },
            r => r.ToCsv(),
            r => r.GetId());

        var storeRepo = new FileRepository<Store>(
            "data/stores.csv",
            line => { var p = line.Split(','); return new Store(p[0], p[1], int.Parse(p[2])); },
            s => s.ToCsv(),
            s => 0); // Store uses string ID

        _authService = new AuthService(userRepo);
        _productService = new ProductService(productRepo);
        _orderService = new OrderService(orderRepo, _notificationService);
        _storeService = new StoreService(storeRepo);
        _cartService = new CartService();
        _reviewService = new ReviewService(reviewRepo, _productService);
        _analyticsService = new AnalyticsService(_orderService, _productService);
    }

    public void Run()
    {
        Console.WriteLine("=== E-Commerce Multi-Vendor Platform ===");
        Console.WriteLine("1. Login");
        Console.WriteLine("2. Register");
        Console.WriteLine("3. Browse as Guest");
        Console.WriteLine("0. Exit");

        var choice = Console.ReadLine();
        switch (choice)
        {
            case "1": HandleLogin(); break;
            case "2": HandleRegister(); break;
            case "3": ShowStorefront(); break;
        }
    }

    private void HandleLogin()
    {
        Console.Write("Email: ");
        var email = Console.ReadLine() ?? "";
        Console.Write("Password: ");
        var password = Console.ReadLine() ?? "";
        _currentUser = _authService.Login(email, password);
        if (_currentUser != null)
        {
            Console.WriteLine($"Mirë se erdhe, {_currentUser.GetName()}!");
            if (_currentUser.GetRole() == UserRole.Seller) ShowAdminPanel();
            else ShowBuyerPanel();
        }
        else Console.WriteLine("Email ose password i gabuar.");
    }

    private void HandleRegister()
    {
        Console.Write("Emri: "); var name = Console.ReadLine() ?? "";
        Console.Write("Email: "); var email = Console.ReadLine() ?? "";
        Console.Write("Password: "); var password = Console.ReadLine() ?? "";
        Console.Write("Adresa: "); var address = Console.ReadLine() ?? "";
        _currentUser = _authService.Register(name, email, password, address, UserRole.Buyer);
        Console.WriteLine("Regjistrimi u krye me sukses!");
    }

    private void ShowAdminPanel()
    {
        Console.WriteLine("\n=== ADMIN PANEL ===");
        Console.WriteLine("1. Menaxho Produktet");
        Console.WriteLine("2. Menaxho Kategoritë");
        Console.WriteLine("3. Menaxho Reklamat");
        Console.WriteLine("4. Shiko Porositë");
        Console.WriteLine("5. Analytics");
        Console.WriteLine("6. Ndrysho Temën e Dyqanit");
        Console.WriteLine("7. Shiko QR Code të Dyqanit");
        // Admin panel menu — logjika e plotë implementohet sipas nevojës
    }

    private void ShowBuyerPanel()
    {
        Console.WriteLine("\n=== PANELI I BLERËSIT ===");
        Console.WriteLine("1. Shiko Produktet");
        Console.WriteLine("2. Shporta");
        Console.WriteLine("3. Porositë e Mia");
        Console.WriteLine("4. Wishlist");
        Console.WriteLine("5. Njoftime");
    }

    private void ShowStorefront()
    {
        Console.WriteLine("\n=== FAQJA KRYESORE ===");
        Console.WriteLine("Kërkoni produkte, shfletoni kategori dhe shumë më tepër.");
    }
}
